# unlockme

1. Open index.html in a browser.
2. Choose "Sensor" to try the sensor-based unlock option. Enable microphone access in your browser. Speak the French words to unlock your phone.
3. Choose "Touch" to try the touch-based unlock option. Touch the clock in order to first match the orange hour hand to the black hour hand, and then touch again to match the orange minute hand to the black minute hand. When both are matched, phone will be unlocked.
