Open the index.html file in a browser window and start clicking and dragging!
