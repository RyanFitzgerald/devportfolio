# 581-finalProject
Final project code for 581


Running Demo of Prototype:

1. Upload code to board.

2. Attach to wiring harness & sensors.

3. Insert phone.

4. Become fashionable.

